 const shim = require('fabric-shim');

const Chaincode = class {

    async Init(stub) {
        return shim.success();
    }

    async Invoke(stub) {
        let ret = stub.getFunctionAndParameters();
        let method = this[ret.fcn];
        console.log("Inside invoke. Calling method: " + ret.fcn);
        if (!method) {
            shim.error(Buffer.from('Received unknown function ' + ret.fcn + ' invocation'));
        }

        try {
            let payload = await method(stub, ret.params);
            return shim.success(payload);
        } catch (err) {
            console.log(err);
            return shim.error(err);
        }
    }
    //Method to save or update a user review to a product
    async insertReceiver(stub, args) {
        console.log("inside insertReceiver: " + JSON.stringify(args));
        if (args.length != 3) {
            throw 'Incorrect number of arguments. Expecting ID,Name and Org.';
        }
        var receiver = {};
		receiver.ObjectType = "receiver";
        receiver.Receiver_id = args[0];
        receiver.Receiver_name = args[1];
        receiver.Upload_org = args[2];
        await stub.putState(receiver.Receiver_id, Buffer.from(JSON.stringify(receiver)));
    }//End of method
	
}
shim.start(new Chaincode());